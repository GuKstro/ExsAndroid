package br.com.gustavo.checkbox;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private CheckBox checkBoxArroz, checkBoxLeite, checkBoxCarne, checkBoxFeijao, checkBoxRefrigerante;
    private TextView totalTextView;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        checkBoxArroz = findViewById(R.id.checkBoxArroz);
        checkBoxLeite = findViewById(R.id.checkBoxLeite);
        checkBoxCarne = findViewById(R.id.checkBoxCarne);
        checkBoxFeijao = findViewById(R.id.checkBoxFeijao);
        checkBoxRefrigerante = findViewById(R.id.checkBoxRefrigerante);
        totalTextView = findViewById(R.id.totalTextView);
        calculateButton = findViewById(R.id.calculateButton);


        calculateButton.setOnClickListener(v -> {
            double total = 0.0;

            if (checkBoxArroz.isChecked()) {
                total += 2.69;
            }
            if (checkBoxLeite.isChecked()) {
                total += 2.70;
            }
            if (checkBoxCarne.isChecked()) {
                total += 16.70;
            }
            if (checkBoxFeijao.isChecked()) {
                total += 3.38;
            }
            if (checkBoxRefrigerante.isChecked()) {
                total += 3.00;
            }

            String totalFormatted = String.format("Total: R$ %.2f", total);
            totalTextView.setText(totalFormatted);
        });
    }
}