package br.com.gustavo.pedidopizzaria;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResumoPedidoActivity extends AppCompatActivity {

    private TextView textResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resumo_pedido);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.resumo), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textResumo = findViewById(R.id.textResumo);

        // Pegando os dados vindos das outras telas
        String tipoPizza = getIntent().getStringExtra("tipoPizza");
        String tamanho = getIntent().getStringExtra("tamanho");
        String metodoPagamento = getIntent().getStringExtra("pagamento");

        // Calculando valor com base no tamanho
        double preco = calcularPreco(tamanho);

        // Mostrando o resumo
        String resumo = "Resumo do Pedido:\n\n" +
                "Tipo de Pizza: " + tipoPizza + "\n" +
                "Tamanho: " + tamanho + "\n" +
                "Pagamento: " + metodoPagamento + "\n" +
                "Valor Total: R$ " + String.format("%.2f", preco);

        textResumo.setText(resumo);
    }

    private double calcularPreco(String tamanhoSelecionado) {
        switch (tamanhoSelecionado) {
            case "Pequena":
                return 30.00;
            case "Média":
                return 45.00;
            case "Grande":
                return 60.00;
            default:
                return 0.00;
        }
    }
}
