package br.com.gustavo.pedidopizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SelecaoTamanhoPagamentoActivity extends AppCompatActivity {

    private RadioGroup radioGroupTamanho, radioGroupPagamento;
    private TextView textPreco;
    private Button btnResumo;
    private String tipoPizzaSelecionada = "";
    private String tamanhoSelecionado = "";
    private String pagamentoSelecionado = "";
    private double precoPizza = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_selecao_tamanho_pagamento);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.tamanho_pagamento), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        radioGroupTamanho = findViewById(R.id.radioGroupTamanho);
        radioGroupPagamento = findViewById(R.id.radioGroupPagamento);
        textPreco = findViewById(R.id.textPreco);
        btnResumo = findViewById(R.id.btnResumo);

        tipoPizzaSelecionada = getIntent().getStringExtra("tipoPizza");

        radioGroupTamanho.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId) {
                case R.id.radioPequena:
                    precoPizza = 30.0;
                    tamanhoSelecionado = "Pequena";
                    break;
                case R.id.radioMedia:
                    precoPizza = 45.0;
                    tamanhoSelecionado = "Média";
                    break;
                case R.id.radioGrande:
                    precoPizza = 60.0;
                    tamanhoSelecionado = "Grande";
                    break;
            }
            textPreco.setText("Preço: R$ " + precoPizza);
        });

        btnResumo.setOnClickListener(v -> {
            int pagamentoId = radioGroupPagamento.getCheckedRadioButtonId();
            if (pagamentoId != -1 && !tamanhoSelecionado.isEmpty()) {
                RadioButton radioPagamento = findViewById(pagamentoId);
                pagamentoSelecionado = radioPagamento.getText().toString();

                Intent intent = new Intent(this, ResumoPedidoActivity.class);
                intent.putExtra("tipoPizza", tipoPizzaSelecionada);
                intent.putExtra("tamanho", tamanhoSelecionado);
                intent.putExtra("pagamento", pagamentoSelecionado);
                intent.putExtra("preco", precoPizza);
                startActivity(intent);
            } else {
                textPreco.setText("Por favor, selecione tamanho e pagamento.");
            }
        });
    }
}
