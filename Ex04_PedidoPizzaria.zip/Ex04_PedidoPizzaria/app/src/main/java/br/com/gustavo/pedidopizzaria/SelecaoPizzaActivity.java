package br.com.gustavo.pedidopizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SelecaoPizzaActivity extends AppCompatActivity {

    CheckBox chkCalabresa, chkMarguerita, chkPortuguesa;
    Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_selecao_pizza);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.selecao_pizza_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        chkCalabresa = findViewById(R.id.chkCalabresa);
        chkMarguerita = findViewById(R.id.chkMarguerita);
        chkPortuguesa = findViewById(R.id.chkPortuguesa);
        btnProximo = findViewById(R.id.btnProximo);

        btnProximo.setOnClickListener(v -> {
            StringBuilder tiposSelecionados = new StringBuilder();

            if (chkCalabresa.isChecked()) tiposSelecionados.append("Calabresa, ");
            if (chkMarguerita.isChecked()) tiposSelecionados.append("Marguerita, ");
            if (chkPortuguesa.isChecked()) tiposSelecionados.append("Portuguesa, ");

            if (tiposSelecionados.length() == 0) {
                Toast.makeText(this, "Selecione pelo menos uma pizza!", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, SelecaoTamanhoPagamentoActivity.class);
                intent.putExtra("pizzas", tiposSelecionados.toString());
                startActivity(intent);
            }
        });
    }
}
