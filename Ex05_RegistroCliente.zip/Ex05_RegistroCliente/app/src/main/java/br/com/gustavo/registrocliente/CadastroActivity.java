package br.com.gustavo.registrocliente;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        EditText nameEditText = findViewById(R.id.nameEditText);

        findViewById(R.id.submitButton).setOnClickListener(v -> {
            String nome = nameEditText.getText().toString();
            Intent intent = new Intent(CadastroActivity.this, ConfirmacaoActivity.class);
            intent.putExtra("NOME_CLIENTE", nome);
            startActivity(intent);
        });
    }
}