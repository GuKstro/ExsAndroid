package br.com.gustavo.lanchonete;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FormularioActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_formulario);

        // Ajusta os insets do sistema para o layout principal
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.formulario), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btnSubmit).setOnClickListener(v -> {
            String nome = ((android.widget.EditText) findViewById(R.id.etName)).getText().toString();
            int selectedLancheId = ((android.widget.RadioGroup) findViewById(R.id.rgLanches)).getCheckedRadioButtonId();

            String lanche = "";
            if (selectedLancheId != -1) {
                android.widget.RadioButton selectedLanche = findViewById(selectedLancheId);
                lanche = selectedLanche.getText().toString();
            }

            Intent intent = new Intent(FormularioActivity.this, ResumoActivity.class);
            intent.putExtra("name", nome);
            intent.putExtra("lanche", lanche);
            startActivity(intent);
        });
    }
}