package br.com.gustavo.lanchonete;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResumoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resumo);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.resumo), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String nome = getIntent().getStringExtra("name");
        String lanche = getIntent().getStringExtra("lanche");

        ((android.widget.TextView) findViewById(R.id.tvResumo)).setText("Pedido de " + nome + ": " + lanche);

        findViewById(R.id.btnRestart).setOnClickListener(v -> {
            Intent intent = new Intent(ResumoActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}